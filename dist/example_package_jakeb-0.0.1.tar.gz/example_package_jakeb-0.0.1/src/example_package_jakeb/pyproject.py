def hello(name):
    print(f"Hello, {name}!")